class User(object):
	# 属性
	def __init__(self, name, idCard, phone_number, card):
		self.name = name
		self.idCard = idCard
		self.phone_number = phone_number
		self.card = card