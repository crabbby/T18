from card import Card
from user import User
import random


class ATM(object):
    # 属性
    def __init__(self, allUsers):
        self.allUsers = allUsers  # 用户字典

    # 方法：对应管理员界面的各个指令
    def createUser(self):
        # 开户
        # 目标：向用户字典中添加键值对（卡号【我们随机分配号码】-键对值-用户【用户内部编码】）
        # 提示：字典类型里面可以存放对象（所以是面对对象编程）
        name = input("请输入您的姓名：")
        idCard = input("请输入您的身份证号：")
        phone_number = input("请输入您的电话号码：")

        perstoreMoney = int(input("请输入预存款金额："))
        if perstoreMoney < 0:
            print("预存款输入有误！开户失败")
            return -1

        # 注意：对上面的输入应当有一个输入检测机制防止乱输入
        # 设置密码
        Passwd_once = input('请设置密码：')
        # 验证密码的一个方法
        if not self.checkPasswd(Passwd_once):
            print('密码输入3次有误，开户失败')
            return -1

        # 信息搜集结束
        # 随机配置一个系统卡号
        cardID = self.randomCardID()

        card = Card(cardID, Passwd_once, perstoreMoney)
        user = User(name, idCard, phone_number, card)

        # 存入字典
        self.allUsers[cardID] = user
        print('请牢记卡号:', cardID)

        # 到此开户成功
        print('开户成功')

    # 查询
    def searchUserInfo(self):
        Want_CardID = input('请输入您要查询的卡号：')
        # 验证这个卡号是否存在
        # 提取用户出来
        user = self.allUsers.get(Want_CardID)
        if not user:
            print('该卡号不存在')
            return -1
        # 判断是否锁定
        if user.card.cardLock:
            print('该卡号已被锁定，请解锁后再进行操作')
            return -1

        if not self.checkPasswd(user.card.card_passwd):
            print('密码输入错误，该卡被锁定，请解锁后再进行操作')
            user.card.cardLock = True
            return -1
        # 验证成功返回卡号信息
        print('卡号：%s      余额：%f' % (user.card.cardID, user.card.card_Money))

    def getMoney(self):
        # 取款
        Want_CardID = input('请输入您的卡号：')
        # 验证这个卡号是否存在
        # 提取用户出来
        user = self.allUsers.get(Want_CardID)
        if not user:
            print('该卡号不存在')
            return -1
        # 判断是否锁定
        if user.card.cardLock:
            print('该卡号已被锁定，请解锁后再进行操作')
            return -1
        if not self.checkPasswd(user.card.card_passwd):
            print('密码输入错误，该卡被锁定，请解锁后再进行操作')
            user.card.cardLock = True
            return -1

        # 判断取钱阶段
        Money = int(input('请输入您想取钱的金额：'))
        if Money < 0:
            print('输入有误，返回主界面')
            return -1
        if Money > user.card.card_Money:
            print('余额不足，取钱操作失败，返回主界面')
            return -1

        # 这里成功取钱
        print('取钱成功，取出金额', Money)
        user.card.card_Money -= Money
        print('账户余额:', user.card.card_Money)

    def saveMoney(self):
        # 存款
        Want_CardID = input('请输入您的卡号：')
        # 验证这个卡号是否存在
        # 提取用户出来
        user = self.allUsers.get(Want_CardID)
        if not user:
            print('该卡号不存在')
            return -1
        # 判断是否锁定
        if user.card.cardLock:
            print('该卡号已被锁定，请解锁后再进行操作')
            return -1
        if not self.checkPasswd(user.card.card_passwd):
            print('密码输入错误，该卡被锁定，请解锁后再进行操作')
            user.card.cardLock = True
            return -1
        # 身份判断成功

        Money = int(input('请输入您想存钱的金额：'))
        if Money < 0:
            print('输入有误，返回主界面')

        user.card.card_Money += Money
        print('存钱成功,账户余额:', user.card.card_Money)

    def transMoney(self):
        # 转账
        Want_CardID = input('请输入您的卡号：')
        # 验证这个卡号是否存在
        # 提取用户出来
        user = self.allUsers.get(Want_CardID)
        if not user:
            print('该卡号不存在')
            return -1
        # 判断是否锁定
        if user.card.cardLock:
            print('该卡号已被锁定，请解锁后再进行操作')
            return -1
        if not self.checkPasswd(user.card.card_passwd):
            print('密码输入错误，该卡被锁定，请解锁后再进行操作')
            user.card.cardLock = True
            return -1
        # 身份判断成功

        # 转账目标
        goal_CardID = input('请输入你想转账的账号：')
        goal_user = self.allUsers.get(goal_CardID)
        if not goal_user:
            print('该卡号不存在')
            return -1
        # 判断是否锁定
        if goal_user.card.cardLock:
            print('该卡号已被锁定，请解锁后再进行操作')
            return -1

        # 转账目标判断成功

        # 开始转账
        Money = int(input('请输入转账金额：'))
        if Money < 0:
            print('输入有误，返回主界面')
        if Money > user.card.card_Money:
            print('余额不足，取钱操作失败，返回主界面')
            return -1

        user.card.card_Money -= Money
        goal_user.card.card_Money += Money

        print('转账成功，转账金额为：', Money)
        print('您的账户余额为：', user.card.card_Money)

    def changePasswd(self):
        # 改密
        Want_CardID = input('请输入您的卡号：')
        # 验证这个卡号是否存在
        # 提取用户出来
        user = self.allUsers.get(Want_CardID)
        if not user:
            print('该卡号不存在')
            return -1
        # 判断是否锁定
        if user.card.cardLock:
            print('该卡号已被锁定，请解锁后再进行操作')
            return -1
        if not self.checkPasswd(user.card.card_passwd):
            print('密码输入错误，该卡被锁定，请解锁后再进行操作')
            user.card.cardLock = True
            return -1
        # 身份判断成功

        new_passwd = input('请输入您的新密码：')
        print('请再次输入您的新密码')
        if not self.checkPasswd(new_passwd):
            print('三次输入输入失败，修改密码操作失败，返回主界面')
            return -1
        print('修改密码成功')
        ser.card.card_passwd = new_passwd

    def lockUser(self):
        # 锁定
        cardNum = input('请输入您的卡号：')
        # 验证这个卡号是否存在
        # 提取用户出来
        user = self.allUsers.get(Want_CardID)
        if not user:
            print('该卡号不存在')
            return -1
        if user.card.cardLock:
            print('该卡号已被锁定，请解锁后再进行操作')
            return -1
        if not self.checkPasswd(user.card.card_passwd):
            print('密码输入错误，锁定失败')
            return -1
        tempIDcard = input('请输入您的身份证号进行验证：')
        if tempIDcard != user.idCard:
            print('身份证号输入有误，锁定失败！')
            return -1

        # 到此锁定账号
        user.card.cardLock = True
        print('账号已锁定')

    def unlockUser(self):
        # 解锁
        cardNum = input('请输入您的卡号：')
        # 验证这个卡号是否存在
        # 提取用户出来
        user = self.allUsers.get(Want_CardID)
        if not user:
            print('该卡号不存在')
            return -1
        if not user.card.cardLock:
            print('改卡号没有锁定，无需解锁，请继续其他操作')
            return -1
        if not self.checkPasswd(user.card.card_passwd):
            print('密码输入错误，解锁失败')
            return -1
        tempIDcard = input('请输入您的身份证号进行验证：')
        if tempIDcard != user.idCard:
            print('身份证号输入有误，解锁失败！')
            return -1

        # 到此解锁账号
        user.card.cardLock = False
        print('账号解锁成功')

    def newCard(self):
        # 补卡
        Want_CardID = input('请输入您的卡号：')
        # 验证这个卡号是否存在
        # 提取用户出来
        user = self.allUsers.get(Want_CardID)
        if not user:
            print('该卡号不存在')
            return -1
        # 判断是否锁定
        if user.card.cardLock:
            print('该卡号已被锁定，请解锁后再进行操作')
            return -1
        if not self.checkPasswd(user.card.card_passwd):
            print('密码输入错误，该卡被锁定，请解锁后再进行操作')
            user.card.cardLock = True
            return -1
        # 身份判断成功
        print('补卡申请已提交，请等候短信通知')

    def killUser(self):
        # 销户
        Want_CardID = input('请输入您的卡号：')
        # 验证这个卡号是否存在
        # 提取用户出来
        user = self.allUsers.get(Want_CardID)
        if not user:
            print('该卡号不存在')
            return -1
        # 判断是否锁定
        if user.card.cardLock:
            print('该卡号已被锁定，请解锁后再进行操作')
            return -1
        if not self.checkPasswd(user.card.card_passwd):
            print('密码输入错误，该卡被锁定，请解锁后再进行操作')
            user.card.cardLock = True
            return -1
        # 身份判断成功
        # 开始进行销户
        del self.allUsers[Want_CardID]
        print('销户成功')

    def checkPasswd(self, realPasswd):
        # 验证密码的一个方法
        for i in range(3):
            tempPasswd = input('尝试第%d次请输入密码：' % (i + 1))
            if tempPasswd == realPasswd:
                return True
        return False

    def randomCardID(self):
        # 随机生成一个卡号
        while True:
            CardId = ''
            for i in range(6):
                ch = chr(random.randrange(ord('0'), ord('9') + 1))
                CardId = CardId + ch
            # 判断是否重复
            if not self.allUsers.get(CardId):
                return CardId