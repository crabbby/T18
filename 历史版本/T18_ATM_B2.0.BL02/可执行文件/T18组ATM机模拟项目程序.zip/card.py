class Card(object):
    # 属性
    def __init__(self, cardID, card_passwd, card_Money):
        self.cardID = cardID
        self.card_passwd = card_passwd
        self.card_Money = card_Money
        self.cardLock = False  # 卡的锁定情况
