from admin import Admin
from atm import ATM
import pickle
import os
filepath =  os.path.join(os.path.cwd(), 'allUsers.txt')#若用txt文件的保存路径


def main():
    # 开机界面
    admin = Admin()

    # 管理员开机
    admin.printAdminView()
    if admin.adminOption():
        print("登录失败")
        return -1
    print("登录成功")

    # 存储所有用户的信息
    # AllUser = {}# 放置一个 字典用来存储用户信息
    # 这里可以传入 外置的一个文件夹
    # 提款机对象
    filepath = r'    '  # 当前目录的地址
    # 空的txt加载会失败，所以加一个错误异常的模块
    try:
        f = open(filepath, 'rb')
        allUsers = pickle.load(f)
        f.close()
    except Exception as e:
        allUsers = {}

    print(allUsers)
    atm = ATM(allUsers)  # 初始化了一个类属性

    # 登陆界面
    while True:
        admin.sysFunctionView()
        option = input("请输入您所需要的操作:")
        if option == "1":
            print('开户')
            atm.createUser()
        elif option == "2":
            print('查询')
            atm.searchUserInfo()
        elif option == "3":
            # 取款
            print('取款')
            atm.getMoney()
        elif option == "4":
            # 存款
            print('存款')
            atm.saveMoney()
        elif option == "5":
            # 转账
            print('转账')
            atm.transMoney()
        elif option == "6":
            # 改密
            print('改密')
            atm.changePasswd()
        elif option == "7":
            # 锁定
            print('锁定')
            atm.lockUser()
        elif option == "8":
            # 解锁
            print('解锁')
            atm.unlockUser()
        elif option == "9":
            # 补卡
            print('补卡')
            atm.newCard()
        elif option == "0":
            # 销户
            print('销户')
            atm.killUser()
        elif option == "t":
            if not admin.adminOption():
                f = open(filepath, 'wb')
                pickle.dump(atm.allUsers, f)
                f.close()
                print('已退出')
                return -1


if __name__ == "__main__":
    main()